# Odometry

## General

```{doxygenfunction} lemlib::update
```

```{doxygenfunction} lemlib::init
```


## Pose

```{doxygenclass} lemlib::Pose
:members:
```

```{doxygenfunction} lemlib::format_as
```
