#include "robodash/apix.h"

void _init_styles() {
	_init_colors();
	_init_style_misc();
	_init_style_text();
	_init_style_btn();
	_init_style_list();
	_init_style_core();
}