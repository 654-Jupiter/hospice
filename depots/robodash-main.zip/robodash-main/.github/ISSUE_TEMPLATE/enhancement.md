---
name: Enhancement
about: Suggest a new feature or idea
title: 'Enhancement: '
labels: enhancement
assignees: unwieldycat

---

**Proposed enhancement**
Describe the change or feature you want.

**Motivation behind change**
Describe why this enhancement would be helpful.
