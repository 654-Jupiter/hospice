---
name: Bug report
about: Report a bug in robodash
title: 'Bug: '
labels: bug
assignees: unwieldycat

---

**Bug description**
Description of what the bug is.

**Expected behavior**
Description of what you expected to happen.

**Steps to reproduce**
Steps to reproduce the behavior, including any necessary code.
